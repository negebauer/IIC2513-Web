Para correr el programa se puede correr directo desde main.rb, en cuyo caso se verifica la carrera_6_camellos. Tambien se puede llamar desde consola con 'ruby main.rb ruta_a_archivo_a_consultar'

Se imprime todo en pantalla

Esta entrega fue realizada en una version Ruby 2.1.5p273 y Rails 4.2.5.2.
Fue probada en Ubuntu y Mac OS X 10.11.3
